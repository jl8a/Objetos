
package gimnasio;

import java.util.ArrayList;
import java.util.Scanner;


public class aparatosGimnasio {
    static Scanner entrada = new Scanner(System.in);
    static ArrayList aparatosGym = new ArrayList();
    
    String nombre;
    String musculo;
    String seccion;
    int cantidad;
    int incremento;
    int pesoMaximo;

    public aparatosGimnasio(String nombre, String musculo, String seccion, int cantidad, int incremento, int pesoMaximo) {
        this.nombre = nombre;
        this.musculo = musculo;
        this.seccion = seccion;
        this.cantidad = cantidad;
        this.incremento = incremento;
        this.pesoMaximo = pesoMaximo;
    }
    

    
    
    public static void describirParaDiferentesMusculos(){
        System.out.println("Escriba el nombre del aparato");
        String nombre = entrada.nextLine();
        System.out.println("Escriba el nombre el musculo a trabajar");
        String musculo = entrada.nextLine();
        System.out.println("Escriba la seccion a trabajar del musculo");
        String seccion = entrada.nextLine();
        System.out.println("Digite la cantidad de dicho aparato");
        int cantidad = entrada.nextInt();
        System.out.println("Incremento minimo");
        int incremento = entrada.nextInt();
        System.out.println("Peso maximo del aparato");
        int pesoMaximo = entrada.nextInt();
        
        aparatosGimnasio aparatoGym = new aparatosGimnasio(nombre,musculo,seccion,cantidad,incremento,pesoMaximo);
        aparatosGym.add(aparatoGym);
    }
}

