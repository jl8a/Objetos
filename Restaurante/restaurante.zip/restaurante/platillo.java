
package restaurante;

import java.util.ArrayList;
import java.util.Scanner;


public class platillo {
     
   static Scanner entrada = new Scanner(System.in); 
   static ArrayList menu = new ArrayList();
    
   String nombrePlatillo;
   String tipoDeComida;
   String ingredientes;
   double precio;
   double cantidadProteina;

    public platillo(String nombrePlatillo, String tipoDeComida, String ingredientes, double precio, double cantidadProteina) {
        this.nombrePlatillo = nombrePlatillo;
        this.tipoDeComida = tipoDeComida;
        this.ingredientes = ingredientes;
        this.precio = precio;
        this.cantidadProteina = cantidadProteina;
    }
   
   public static void agragarPlatilloAlMenu(){
       System.out.println("Ingrese el nombre del platillo");
       String nombrePlatillo = entrada.nextLine();
       System.out.println("Que tipo de comida es");
       String tipoDeComida = entrada.nextLine();
       System.out.println("Ingrese los ingredientes");
       String ingredientes = entrada.nextLine();
       System.out.println("Ingrese el precio");
       double precio = entrada.nextDouble();
       System.out.println("Ingrese la cantidad de proteina del platillo");
       double cantidadProteina = entrada.nextDouble();
       
       platillo comida = new platillo(nombrePlatillo, tipoDeComida, ingredientes, precio, cantidadProteina);
       menu.add(comida);
    }
   
   
    
    
    
    
    
    
}
