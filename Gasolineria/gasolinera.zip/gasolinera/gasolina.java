
package gasolinera;

import java.util.ArrayList;
import java.util.Scanner;

public class gasolina {
    
    static Scanner entrada = new Scanner(System.in);
    static ArrayList tipoGasolinas = new ArrayList();
    
    String nombreCombustible;
    int numeroOctanos;
    double precioPorLitro;

    public gasolina(String nombreCombustible, int numeroOctanos, double precioPorLitro) {
        this.nombreCombustible = nombreCombustible;
        this.numeroOctanos = numeroOctanos;
        this.precioPorLitro = precioPorLitro;
    }
    
    public static void agregarCombustible(){
        
        System.out.println("Digite el nombre del combustible");
        String nombreCombustible = entrada.nextLine();
        System.out.println("Ingrese el numero de octanos");
        int numeroOctanos = entrada.nextInt();
        System.out.println("Ingrese el precio por litro");
        double precioPorLitro = entrada.nextDouble();
        
        gasolina tipoCombustible = new gasolina(nombreCombustible,numeroOctanos,precioPorLitro);
        
        tipoGasolinas.add(tipoCombustible);
    }
    
    
    
}
