
package parque;

import java.util.ArrayList;
import java.util.Scanner;


public class juegosInfantiles {
    
    static Scanner entrada = new Scanner(System.in);
    static ArrayList juegos = new ArrayList();
    
    String nombre;
    int cantidad;
    int edadMinima;
    int cantidadDePersonas;

    public juegosInfantiles(String nombre,  int cantidad, int edadMinima, int cantidadDePersonas) {
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.edadMinima = edadMinima;
        this.cantidadDePersonas = cantidadDePersonas;
    }
    
    

    

    public static void registrarJuegosInfantiles(){
        
        System.out.println("Ingrese el nombre del juego");
        String nombre = entrada.nextLine();
        System.out.println("Escriba la cantidad de dicho juego");
        int cantidad = entrada.nextInt();
        System.out.println("Escriba a edad minima para este utilizar este juego");
        int edadMinima = entrada.nextInt();
        System.out.println("Escriba la cantidad de personas maxima para utiliar este juego");
        int cantidadDePersonas = entrada.nextInt();
        
        juegosInfantiles juego = new juegosInfantiles(nombre,cantidad,edadMinima,cantidadDePersonas);
        juegos.add(juego);
        
    }
    
    
    
}
