
package escuela;

import java.util.ArrayList;
import java.util.Scanner;

public class centroDeComputo {
    
    static Scanner entrada = new Scanner(System.in);
    static ArrayList salones = new ArrayList();
    
    int cantidadComputadoras;
    int cantidadSillas;
    int cantidadDeMesas;
    String tipoDeMesa;
    boolean aireAcondicionado;

    public centroDeComputo(int cantidadComputadoras, int cantidadSillas, int cantidadDeMesas, String tipoDeMesa) {
        this.cantidadComputadoras = cantidadComputadoras;
        this.cantidadSillas = cantidadSillas;
        this.cantidadDeMesas = cantidadDeMesas;
        this.tipoDeMesa = tipoDeMesa;
        this.aireAcondicionado = true;
    }

    public static void diseñarCentroDeComputo(){
        System.out.println("Ingrese el numero de computadoras");
        int cantidadComputadoras = entrada.nextInt();
        System.out.println("Ingrese la cantidad de sillas");
        int cantidadSillas = entrada.nextInt();
        System.out.println("Ingrese el cantidad de mesas");
        int cantidadDeMesas = entrada.nextInt();
        System.out.println("Ingrese el tipo de mesas");
        String tipoDeMesa = entrada.nextLine();
        
        
        centroDeComputo laboratorio = new centroDeComputo(cantidadComputadoras,cantidadSillas,cantidadDeMesas,tipoDeMesa);
        
        salones.add(laboratorio);
    }

    
    
    
}
