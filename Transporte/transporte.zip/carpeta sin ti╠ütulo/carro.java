
package transporte;

import java.util.ArrayList;
import java.util.Scanner;


public class carro {
    static Scanner entrada = new Scanner(System.in);
    static ArrayList listaCarros = new ArrayList();
    int idCarro;
    String marca;
    String nombreCarro;
    String tipoCarro;
    int cantidad;
    boolean disponible;
    double precioPorDia;
    int numeroPuertas;
    int capacidadDePersonas;
    int cilindros;
    String combustible; 
    int capacidadTanque;
    double litrosPorKm;
    double cantcombustibleActual;
    double kmRecorridos;

    public carro(int idCarro,String marca, String nombreCarro, String tipoCarro, int cantidad, double precioPorDia, int capacidadDePersonas, int cilindros, String combustible,int capacidadTanque, double litrosPorKm, double cantcombustibleActual, double kmRecorridos) {
        this.idCarro = idCarro;
        this.marca = marca;
        this.nombreCarro = nombreCarro;
        this.tipoCarro = tipoCarro;
        this.cantidad = cantidad;
        this.disponible = true;
        this.precioPorDia = precioPorDia;
        this.capacidadDePersonas = capacidadDePersonas;
        this.cilindros = cilindros;
        this.combustible = combustible;
        this.capacidadTanque = capacidadTanque;
        this.litrosPorKm = litrosPorKm;
        this.cantcombustibleActual = cantcombustibleActual;
        this.kmRecorridos = kmRecorridos;
    }
    
    public static void registrarCarros(){
        System.out.println("Escriba id del carro");
        int idCarro = entrada.nextInt();
        System.out.println("Escriba la marca del carro");
        String marca = entrada.nextLine();
        System.out.println("Escriba el nombre del carro");
        String nombreCarro = entrada.nextLine();
        System.out.println("Escriba el tipo de carro");
        String tipoCarro = entrada.nextLine();
        System.out.println("Escriba las unidades de dicho carro");
        int cantidad = entrada.nextInt();
        System.out.println("Escriba costo por renta");
        double precioPorDia = entrada.nextDouble();
        System.out.println("Escriba la capacidad del carro");
        int capacidadDePersonas  = entrada.nextInt();
        System.out.println("Escriba los cilindros del carro");
        int cilindros = entrada.nextInt();
        System.out.println("Escriba el tipo de combustible que usa");
        String combustible = entrada.nextLine();
        System.out.println("Escriba la capacidad del tanque");
        int capacidadTanque = entrada.nextInt();
        System.out.println("Escriba gasto por km");
        double litrosPorKm = entrada.nextDouble();
        System.out.println("Escribe la cantidad actual de gasolina");
        double cantcombustibleActual = entrada.nextDouble();
        System.out.println("Escriba los km recorridos");
        double kmRecorridos = entrada.nextInt();
        
        carro autos = new carro(idCarro,marca,nombreCarro,tipoCarro,cantidad,precioPorDia,capacidadDePersonas,cilindros,combustible,capacidadTanque,litrosPorKm,cantcombustibleActual,kmRecorridos);
        
        listaCarros.add(autos);
    }
    
    
}
