
package iglesia;

import java.util.ArrayList;
import java.util.Scanner;


public class subCapilla {
   static Scanner entrada = new Scanner(System.in);
   static ArrayList salones = new ArrayList();
   
   
    int cantidadBancas;
    int capacidadPorBancas;
    int reclinatorios;
    int capacidadReclinatorio;

    public subCapilla(int cantidadBancas, int capacidadPorBancas, int reclinatorios, int capacidadReclinatorio) {
        this.cantidadBancas = cantidadBancas;
        this.capacidadPorBancas = capacidadPorBancas;
        this.reclinatorios = reclinatorios;
        this.capacidadReclinatorio = capacidadReclinatorio;
    }
    
    public static void crearSubCapilla(){
        System.out.println("Cantidad de bancas");
        int cantidadBancas = entrada.nextInt();
        System.out.println("Capacidad por banca");
        int capacidadPorBancas = entrada.nextInt();
        System.out.println("Cantidad de reclinatorios");
        int reclinatorios = entrada.nextInt();
        System.out.println("Capacidad de reclinatorios");
        int capacidadReclinatorio = entrada.nextInt();
        
        subCapilla salon = new subCapilla(cantidadBancas,capacidadPorBancas,reclinatorios,capacidadReclinatorio);
        salones.add(salon);
    }
    
     
    
}
